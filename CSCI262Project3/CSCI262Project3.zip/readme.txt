Drew Remmenga
I was challenged by making sure that a given word would unlock all instances of a letter. I liked how structured and transparent the assigment was in terms of coding. 
4 hrs